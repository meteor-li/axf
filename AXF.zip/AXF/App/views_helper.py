import hashlib

# from django.core.mail import send_mail
from django.template import loader
import smtplib
from email.mime.text import MIMEText

from AXF.settings import *
from App.models import Cart


def hash_str(source):
    return hashlib.new('sha512', source.encode('utf-8')).hexdigest()


def send_email_activate(username,email,token):
    # 邮件服务器
    mail_server = 'smtp.qq.com'
    # 用户名
    mail_username = '1337983798@qq.com'
    # 密码，通过环境变量获取，可以避免隐私信息的暴露
    # 或授权码，QQ邮箱需要使用授权码
    mail_password = 'fxtlwernbugpbadd'
    # 邮件内容
    data = {
                'username': username,
                'activate_url': 'http://{}:{}/axf/activate/?u_token={}'.format(SERVER_HOST, SERVER_PORT,token)
            }

    content = loader.get_template('user/activate.html').render(data)
    html_message =MIMEText(content,_subtype='html',_charset='utf-8')
    # 设置主题
    html_message['Subject'] = '用户激活'
    # # 设置发送者
    html_message['From'] = mail_username

    mail = smtplib.SMTP(mail_server)
    # 身份认证
    mail.login(mail_username, mail_password)
    # 发送给谁
    to = email
    # 发送邮件
    mail.sendmail(mail_username, to, html_message.as_string())
    # 结束
    mail.quit()
# def send_email_activate(username, receive, u_token):
#
#     subject = '%s AXF Activate' % username
#
#     from_email = EMAIL_HOST_USER
#
#     recipient_list = [receive,]
#
#     data = {
#         'username': username,
#         'activate_url': 'http://{}:{}/axf/activate/?u_token={}'.format(SERVER_HOST, SERVER_PORT, u_token)
#     }
#
#     html_message = loader.get_template('user/activate.html').render(data)
#
#     send_mail(subject=subject, message="", html_message=html_message, from_email=from_email, recipient_list=recipient_list)


def get_total_price():

    carts = Cart.objects.filter(c_is_select=True)

    total = 0

    for cart in carts:
        total += cart.c_goods_num * cart.c_goods.price

    return "{:.2f}".format(total)